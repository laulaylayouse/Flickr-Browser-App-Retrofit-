package com.example.flickrbrowserapp_laila

import com.example.flickrbrowserappretrofit.Photos
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface APIInterface {

    @Headers("Content-Type: application/json")
    @GET("/services/rest/?method=flickr.photos.search&api_key=732fad76524987681acc5e9889c1d636&format=json&nojsoncallback=1&extras=url_t")
    fun getPhoto(@Query("text") tag: String): Call<Photos>

}