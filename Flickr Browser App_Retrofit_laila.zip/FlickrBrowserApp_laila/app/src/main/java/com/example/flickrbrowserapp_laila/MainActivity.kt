package com.example.flickrbrowserapp_laila

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var EditText_Search: EditText
    lateinit var Button_Search: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        EditText_Search = findViewById(R.id.EditText_Search)
        Button_Search = findViewById(R.id.Button_Search)
        Button_Search.setOnClickListener {

            var Input_Value = EditText_Search.text.toString()

            if (Input_Value.isEmpty())
            {
                Toast.makeText(applicationContext, "Please put what you want to search!".uppercase(), Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, ViewActivity::class.java)
                intent.putExtra("search Value", Input_Value)
                startActivity(intent)
            }
        }

    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.refresh -> {
                EditText_Search.setText("")
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}