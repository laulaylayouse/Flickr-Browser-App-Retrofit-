package com.example.flickrbrowserappretrofit

data class Photo(
    val title: String,
    val url_t: String
)