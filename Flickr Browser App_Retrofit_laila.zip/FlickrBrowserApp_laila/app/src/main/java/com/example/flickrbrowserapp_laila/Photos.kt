package com.example.flickrbrowserappretrofit

data class Photos(
    val photos: Photos_Page
)