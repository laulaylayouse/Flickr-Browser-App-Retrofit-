package com.example.flickrbrowserappretrofit

data class Photos_Page(
    val photo: List<Photo>
)